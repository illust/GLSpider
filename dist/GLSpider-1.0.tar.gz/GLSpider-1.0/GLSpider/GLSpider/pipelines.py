# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://doc.scrapy.org/en/latest/topics/item-pipeline.html
from scrapy.utils.project import get_project_settings
import hashlib
import os
import json

class GlspiderPipeline(object):
    def process_item(self, item, spider):
        return item

import hashlib
class html2FilePipeline(object):
    def process_item(self, item, htm2f):
        settings = get_project_settings()
        folder = settings.get('HTMLFOLDER')
        file_name = hashlib.sha224(item['url'].encode('utf-8')).hexdigest() #chose whatever hashing func works for you
        with open('%s/%s.html' % (folder,file_name), 'w+b') as f:
            f.write(item['html'])

class JsonWriterPipeline(object):

    def open_spider(self,sku):
        settings = get_project_settings()
        folder = settings.get('JSONFOLDER')
        name = settings.get('JSONNAME')
        self.file = open('%s/%s.json'%(folder,name),'w')

    def close_spider(self,sku):
        self.file.close()

    def process_item(self,item,sku):
        line = json.dumps(item,ensure_ascii=False) + "," + "\n"
        self.file.write(line)
        return item

