#!/usr/bin/env python
#-*- coding:utf-8 -*-
import optparse
import scrapy.cmdline as cmd
import subprocess
import os

def test():
    usage = "GLSpider <command> [options] [args]"
    parser = optparse.OptionParser(usage)
    parser.add_option("-i","--infile",dest="infile",help="read configure info from file",metavar="FILE",action="store",type="string")
    parser.add_option("-o","--outfile",dest="outfile",help="save scraped data to file",metavar="FILE",action="store",type="string")
    # parser.add_option("")
    
    options,args=parser.parse_args()

    if options.infile != "":
        path = os.getcwd()
        subprocess.call('cd %s&&scrapy crawl sku'%path,shell=True)
        #cmd.execute('scrapy crawl sku'.split())
    
 

    
if __name__ == '__main__':
    test()